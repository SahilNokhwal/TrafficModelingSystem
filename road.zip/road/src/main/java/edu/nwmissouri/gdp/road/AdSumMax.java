package edu.nwmissouri.gdp.road;

public class AdSumMax {

	public static void main(String[] args) {


		int[] arr = {5, 5, 10, 100, 10, 5};
		
		if(arr.length==0){
			
		}
		int sum = 0;  
		for(int i=0;i<arr.length;i++){
			
		}

	}

}
