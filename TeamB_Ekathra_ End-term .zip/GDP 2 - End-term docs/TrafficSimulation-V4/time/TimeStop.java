package time;

/**
 * Class representing a TimeStop Exception
 *
 * 
 */
public class TimeStop extends Exception {

    public TimeStop(String s) {super(s);}
    public TimeStop() {super();}

}
