/*
 * 
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utils.scaling;

/**
 * 
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public abstract class Params {
	public double xscale, yscale;
	public double xmin, ymin;
	public double xmax, ymax;
	public double xmid, ymid;
}
