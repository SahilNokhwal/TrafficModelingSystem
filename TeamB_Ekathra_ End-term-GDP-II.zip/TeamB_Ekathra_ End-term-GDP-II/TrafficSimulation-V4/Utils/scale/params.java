/*
 * 
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utils.scale;

/**
 * 
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class params {
    double xscale,yscale;
    double xmin,xmax;
    double ymin,ymax;
    double xmid,ymid;
    params()
	{
    	xscale = yscale = 0;
    	xmin = xmax = 0;
    	ymin = ymax = 0;
    	xmid = ymid = 0;
	}
}
