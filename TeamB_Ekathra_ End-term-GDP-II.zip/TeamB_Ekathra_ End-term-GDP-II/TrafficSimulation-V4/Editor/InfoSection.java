
public class InfoSection {
	public int index = 0;
	public double x, y;
	public String Name;
	
	public InfoSection(String name) {
		Name = name;
	}
}
